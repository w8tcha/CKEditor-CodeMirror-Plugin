﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'codemirror', 'uk', {
	toolbar: 'Джерело',
	searchCode: 'Шукати в джерелі',
	autoFormat: 'Форматувати вибране',
	commentSelectedRange: 'Закоментувати вибране',
	uncommentSelectedRange: 'Розкоментувати вибране',
	autoCompleteToggle: 'Увімкнути/Вимкнути автоматичне завершення HTML-тегів'
});
